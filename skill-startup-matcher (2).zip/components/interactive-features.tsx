"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"
import {
  Users,
  Briefcase,
  MessageSquare,
  Award,
  TrendingUp,
  Zap,
  ChevronDown,
  ChevronUp,
  Star,
  MapPin,
  Clock,
  DollarSign,
  Send,
  Upload,
  Bell,
  CheckCircle,
  Filter,
  BarChart3,
  PieChart,
  Target,
  Mail,
  Calendar,
  FileText,
} from "lucide-react"

const features = [
  {
    id: "smart-matching",
    title: "Smart Matching",
    description: "AI-powered algorithm matches students with startups based on skills, interests, and availability",
    icon: Users,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
  },
  {
    id: "diverse-opportunities",
    title: "Diverse Opportunities",
    description: "Find gigs, internships, hackathons, and full-time positions across various industries",
    icon: Briefcase,
    color: "text-indigo-600",
    bgColor: "bg-indigo-50",
  },
  {
    id: "direct-communication",
    title: "Direct Communication",
    description: "Built-in messaging system for seamless communication between students and startups",
    icon: MessageSquare,
    color: "text-green-600",
    bgColor: "bg-green-50",
  },
  {
    id: "skill-verification",
    title: "Skill Verification",
    description: "Optional skill assessments and portfolio showcases to verify and highlight expertise",
    icon: Award,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
  },
  {
    id: "analytics-dashboard",
    title: "Analytics Dashboard",
    description: "Track applications, match scores, and success rates with detailed analytics",
    icon: TrendingUp,
    color: "text-orange-600",
    bgColor: "bg-orange-50",
  },
  {
    id: "realtime-updates",
    title: "Real-time Updates",
    description: "Get instant notifications for new matches, applications, and opportunities",
    icon: Zap,
    color: "text-red-600",
    bgColor: "bg-red-50",
  },
]

const mockOpportunities = [
  {
    id: 1,
    title: "Frontend Developer Intern",
    company: "TechStart Inc.",
    type: "Internship",
    location: "Remote",
    duration: "3 months",
    compensation: "$1,500/month",
    skills: ["React", "JavaScript", "UI/UX Design"],
    matchScore: 95,
    industry: "Tech",
    email: "hr@techstart.com",
    applied: false,
  },
  {
    id: 2,
    title: "Marketing Assistant",
    company: "GrowthCorp",
    type: "Gig",
    location: "New York, NY",
    duration: "2 weeks",
    compensation: "$800",
    skills: ["Digital Marketing", "Content Creation"],
    matchScore: 88,
    industry: "Marketing",
    email: "jobs@growthcorp.com",
    applied: false,
  },
  {
    id: 3,
    title: "UI/UX Design Challenge",
    company: "DesignHub",
    type: "Hackathon",
    location: "San Francisco, CA",
    duration: "48 hours",
    compensation: "$3,000 prize",
    skills: ["UI/UX Design", "Figma", "Prototyping"],
    matchScore: 92,
    industry: "Design",
    email: "events@designhub.com",
    applied: false,
  },
]

export default function InteractiveFeatures() {
  const [expandedFeature, setExpandedFeature] = useState<string | null>(null)
  const [studentProfile, setStudentProfile] = useState({
    name: "John Smith",
    email: "john.smith@university.edu",
    skills: ["React", "JavaScript"],
    interests: ["Tech", "AI"],
    availability: "Part-time",
  })
  const [filterType, setFilterType] = useState("all")
  const [filterIndustry, setFilterIndustry] = useState("all")
  const [appliedJobs, setAppliedJobs] = useState<number[]>([])
  const [chatMessages, setChatMessages] = useState([
    {
      id: 1,
      sender: "startup",
      message: "Hi! We're interested in your profile for our frontend internship.",
      time: "2:30 PM",
    },
    { id: 2, sender: "student", message: "Thank you! I'd love to learn more about the role.", time: "2:32 PM" },
    { id: 3, sender: "startup", message: "Great! When would be a good time for a quick call?", time: "2:35 PM" },
  ])
  const [newMessage, setNewMessage] = useState("")
  const [skillTest, setSkillTest] = useState({ skill: "", started: false, completed: false, score: 0 })
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([])
  const [notifications, setNotifications] = useState([
    { id: 1, type: "match", message: "New match with TechStart Inc.!", time: "5 min ago", read: false },
    { id: 2, type: "application", message: "Application status updated", time: "1 hour ago", read: false },
    { id: 3, type: "message", message: "New message from DesignHub", time: "2 hours ago", read: true },
  ])

  const toggleFeature = (featureId: string) => {
    setExpandedFeature(expandedFeature === featureId ? null : featureId)
  }

  const addSkill = (skill: string) => {
    if (!studentProfile.skills.includes(skill)) {
      setStudentProfile({
        ...studentProfile,
        skills: [...studentProfile.skills, skill],
      })
      toast({
        title: "Skill Added!",
        description: `${skill} has been added to your profile.`,
      })
    }
  }

  const applyToJob = async (opportunity: any) => {
    if (appliedJobs.includes(opportunity.id)) {
      toast({
        title: "Already Applied",
        description: "You have already applied to this position.",
        variant: "destructive",
      })
      return
    }

    // Simulate API call
    try {
      setAppliedJobs([...appliedJobs, opportunity.id])

      // Send email notification (simulated)
      await sendEmailNotification(opportunity)

      // Add notification
      const newNotification = {
        id: notifications.length + 1,
        type: "application",
        message: `Successfully applied to ${opportunity.title} at ${opportunity.company}`,
        time: "Just now",
        read: false,
      }
      setNotifications([newNotification, ...notifications])

      toast({
        title: "Application Submitted!",
        description: `Your application for ${opportunity.title} has been sent to ${opportunity.company}. You'll receive a confirmation email shortly.`,
      })
    } catch (error) {
      toast({
        title: "Application Failed",
        description: "There was an error submitting your application. Please try again.",
        variant: "destructive",
      })
    }
  }

  const sendEmailNotification = async (opportunity: any) => {
    // Simulate email sending
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`Email sent to ${studentProfile.email} and ${opportunity.email}`)
        console.log(`Subject: Application Submitted - ${opportunity.title}`)
        console.log(`Student: ${studentProfile.name} applied for ${opportunity.title} at ${opportunity.company}`)
        resolve(true)
      }, 1000)
    })
  }

  const sendMessage = () => {
    if (newMessage.trim()) {
      const message = {
        id: chatMessages.length + 1,
        sender: "student",
        message: newMessage,
        time: "Now",
      }
      setChatMessages([...chatMessages, message])
      setNewMessage("")

      toast({
        title: "Message Sent!",
        description: "Your message has been sent to the startup.",
      })

      // Simulate startup response
      setTimeout(() => {
        const response = {
          id: chatMessages.length + 2,
          sender: "startup",
          message: "Thanks for your message! We'll get back to you within 24 hours.",
          time: "Now",
        }
        setChatMessages((prev) => [...prev, response])
      }, 2000)
    }
  }

  const shareResume = () => {
    toast({
      title: "Resume Shared!",
      description: "Your resume has been shared with the startup.",
    })

    const message = {
      id: chatMessages.length + 1,
      sender: "student",
      message: "📄 I've shared my resume with you. Looking forward to hearing from you!",
      time: "Now",
    }
    setChatMessages([...chatMessages, message])
  }

  const scheduleInterview = () => {
    toast({
      title: "Interview Request Sent!",
      description: "Your interview request has been sent. The startup will respond with available times.",
    })

    const message = {
      id: chatMessages.length + 1,
      sender: "student",
      message: "📅 I'd like to schedule an interview. When would be a good time for you?",
      time: "Now",
    }
    setChatMessages([...chatMessages, message])
  }

  const startSkillTest = (skill: string) => {
    setSkillTest({ skill, started: true, completed: false, score: 0 })

    // Simulate test progress
    setTimeout(() => {
      const score = Math.floor(Math.random() * 20) + 80 // Score between 80-100
      setSkillTest({ skill, started: true, completed: true, score })

      toast({
        title: "Assessment Complete!",
        description: `You scored ${score}% on the ${skill} assessment and earned a verified badge!`,
      })
    }, 3000)
  }

  const uploadFile = (fileName: string) => {
    setUploadedFiles([...uploadedFiles, fileName])
    toast({
      title: "File Uploaded!",
      description: `${fileName} has been added to your portfolio.`,
    })
  }

  const markNotificationRead = (id: number) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const filteredOpportunities = mockOpportunities.filter((opp) => {
    const typeMatch = filterType === "all" || opp.type.toLowerCase() === filterType
    const industryMatch = filterIndustry === "all" || opp.industry.toLowerCase() === filterIndustry
    return typeMatch && industryMatch
  })

  const renderFeatureDemo = (featureId: string) => {
    switch (featureId) {
      case "smart-matching":
        return (
          <div className="space-y-6" id="smart-matching">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Student Profile Input */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Your Profile
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Skills</label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {studentProfile.skills.map((skill) => (
                        <Badge key={skill} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Button size="sm" variant="outline" onClick={() => addSkill("Python")}>
                        + Python
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => addSkill("Node.js")}>
                        + Node.js
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => addSkill("UI/UX Design")}>
                        + UI/UX Design
                      </Button>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Interests</label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {studentProfile.interests.map((interest) => (
                        <Badge key={interest} variant="outline">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Availability</label>
                    <Select
                      value={studentProfile.availability}
                      onValueChange={(value) => setStudentProfile({ ...studentProfile, availability: value })}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Full-time">Full-time</SelectItem>
                        <SelectItem value="Part-time">Part-time</SelectItem>
                        <SelectItem value="Weekends">Weekends</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* AI Matching Results */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-yellow-500" />
                    AI Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {mockOpportunities.slice(0, 2).map((opp) => (
                    <div key={opp.id} className="border rounded-lg p-3">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-semibold text-sm">{opp.title}</h4>
                          <p className="text-xs text-gray-600">{opp.company}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-green-600">{opp.matchScore}%</div>
                          <div className="text-xs text-gray-500">Match</div>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {opp.skills.slice(0, 2).map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                      <Button
                        size="sm"
                        className="w-full"
                        onClick={() => applyToJob(opp)}
                        disabled={appliedJobs.includes(opp.id)}
                      >
                        {appliedJobs.includes(opp.id) ? "Applied ✓" : "Quick Apply"}
                      </Button>
                    </div>
                  ))}
                  <Button className="w-full bg-transparent" size="sm" variant="outline">
                    View All Matches
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case "diverse-opportunities":
        return (
          <div className="space-y-6" id="diverse-opportunities">
            {/* Filters */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex gap-4 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="internship">Internship</SelectItem>
                        <SelectItem value="gig">Gig</SelectItem>
                        <SelectItem value="hackathon">Hackathon</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Select value={filterIndustry} onValueChange={setFilterIndustry}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Industries</SelectItem>
                      <SelectItem value="tech">Tech</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="design">Design</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Opportunities Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredOpportunities.map((opp) => (
                <Card key={opp.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-semibold">{opp.title}</h4>
                          <p className="text-sm text-blue-600">{opp.company}</p>
                        </div>
                        <Badge variant="secondary">{opp.type}</Badge>
                      </div>

                      <div className="space-y-2 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-3 w-3" />
                          {opp.location}
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-3 w-3" />
                          {opp.duration}
                        </div>
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-3 w-3" />
                          {opp.compensation}
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {opp.skills.map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex justify-between items-center pt-2">
                        <div className="text-sm font-semibold text-green-600">{opp.matchScore}% Match</div>
                        <Button size="sm" onClick={() => applyToJob(opp)} disabled={appliedJobs.includes(opp.id)}>
                          {appliedJobs.includes(opp.id) ? "Applied ✓" : "Apply"}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case "direct-communication":
        return (
          <div className="max-w-2xl mx-auto" id="direct-communication">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Chat with TechStart Inc.
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Chat Messages */}
                  <div className="h-64 overflow-y-auto border rounded-lg p-4 space-y-3">
                    {chatMessages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender === "student" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-xs px-3 py-2 rounded-lg ${
                            msg.sender === "student" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-900"
                          }`}
                        >
                          <p className="text-sm">{msg.message}</p>
                          <p className="text-xs opacity-70 mt-1">{msg.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Message Input */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                    />
                    <Button onClick={sendMessage}>
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Quick Actions */}
                  <div className="flex gap-2 flex-wrap">
                    <Button variant="outline" size="sm" onClick={shareResume}>
                      <FileText className="h-3 w-3 mr-1" />
                      Share Resume
                    </Button>
                    <Button variant="outline" size="sm" onClick={scheduleInterview}>
                      <Calendar className="h-3 w-3 mr-1" />
                      Schedule Interview
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case "skill-verification":
        return (
          <div className="max-w-2xl mx-auto space-y-6" id="skill-verification">
            <Tabs defaultValue="assessment" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="assessment">Skill Assessment</TabsTrigger>
                <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              </TabsList>

              <TabsContent value="assessment" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Take Skill Assessment</CardTitle>
                    <CardDescription>Verify your skills with quick assessments</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {!skillTest.started ? (
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {["React", "Python", "UI/UX Design", "Node.js", "Data Science", "Digital Marketing"].map(
                          (skill) => (
                            <Button
                              key={skill}
                              variant="outline"
                              onClick={() => startSkillTest(skill)}
                              className="h-20 flex flex-col items-center justify-center"
                            >
                              <Award className="h-6 w-6 mb-2" />
                              {skill}
                            </Button>
                          ),
                        )}
                      </div>
                    ) : (
                      <div className="text-center space-y-4">
                        {!skillTest.completed ? (
                          <>
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                            <p>Taking {skillTest.skill} assessment...</p>
                            <Progress value={66} className="w-full" />
                            <p className="text-sm text-gray-600">Please wait while we evaluate your responses...</p>
                          </>
                        ) : (
                          <>
                            <CheckCircle className="h-16 w-16 text-green-600 mx-auto" />
                            <h3 className="text-xl font-semibold">Assessment Complete!</h3>
                            <p>
                              You scored <span className="font-bold text-green-600">{skillTest.score}%</span> on the{" "}
                              {skillTest.skill} assessment
                            </p>
                            <Badge className="bg-green-100 text-green-800">
                              <Award className="h-3 w-3 mr-1" />
                              {skillTest.skill} Verified
                            </Badge>
                            <Button
                              onClick={() => setSkillTest({ skill: "", started: false, completed: false, score: 0 })}
                              className="mt-4"
                            >
                              Take Another Assessment
                            </Button>
                          </>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="portfolio" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Portfolio Showcase</CardTitle>
                    <CardDescription>Upload your projects and work samples</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-2">Drag & drop files or click to upload</p>
                      <p className="text-sm text-gray-500">PDF, Images, or GitHub links</p>
                      <div className="flex gap-2 justify-center mt-4">
                        <Button onClick={() => uploadFile("My_Portfolio.pdf")}>Upload PDF</Button>
                        <Button variant="outline" onClick={() => uploadFile("Project_Screenshots.zip")}>
                          Upload Images
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">Your Portfolio Items:</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                              <Briefcase className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-medium">E-commerce Website</p>
                              <p className="text-sm text-gray-600">React, Node.js</p>
                            </div>
                          </div>
                          <Badge variant="secondary">Verified</Badge>
                        </div>

                        {uploadedFiles.map((file, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                                <FileText className="h-5 w-5 text-green-600" />
                              </div>
                              <div>
                                <p className="font-medium">{file}</p>
                                <p className="text-sm text-gray-600">Just uploaded</p>
                              </div>
                            </div>
                            <Badge className="bg-green-100 text-green-800">New</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )

      case "analytics-dashboard":
        return (
          <div className="space-y-6" id="analytics-dashboard">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Stats Cards */}
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Applications Sent</p>
                      <p className="text-3xl font-bold text-blue-600">{appliedJobs.length + 21}</p>
                    </div>
                    <BarChart3 className="h-8 w-8 text-blue-600" />
                  </div>
                  <p className="text-sm text-green-600 mt-2">↑ 12% from last week</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Avg Match Score</p>
                      <p className="text-3xl font-bold text-green-600">87%</p>
                    </div>
                    <Target className="h-8 w-8 text-green-600" />
                  </div>
                  <p className="text-sm text-green-600 mt-2">↑ 5% improvement</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Response Rate</p>
                      <p className="text-3xl font-bold text-purple-600">68%</p>
                    </div>
                    <PieChart className="h-8 w-8 text-purple-600" />
                  </div>
                  <p className="text-sm text-green-600 mt-2">↑ 8% from last month</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Application Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Under Review</span>
                      <div className="flex items-center gap-2">
                        <Progress value={45} className="w-20" />
                        <span className="text-sm font-medium">45%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Accepted</span>
                      <div className="flex items-center gap-2">
                        <Progress value={25} className="w-20" />
                        <span className="text-sm font-medium">25%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Rejected</span>
                      <div className="flex items-center gap-2">
                        <Progress value={30} className="w-20" />
                        <span className="text-sm font-medium">30%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {appliedJobs.length > 0 ? (
                      appliedJobs.map((jobId) => {
                        const job = mockOpportunities.find((opp) => opp.id === jobId)
                        return job ? (
                          <div key={jobId} className="flex justify-between items-center p-2 border rounded">
                            <div>
                              <p className="font-medium text-sm">{job.title}</p>
                              <p className="text-xs text-gray-600">{job.company}</p>
                            </div>
                            <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                          </div>
                        ) : null
                      })
                    ) : (
                      <p className="text-gray-500 text-sm">No applications yet. Start applying to see your progress!</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case "realtime-updates":
        return (
          <div className="max-w-2xl mx-auto space-y-6" id="realtime-updates">
            {/* Notification Bell Demo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Live Notifications
                  <div className="relative">
                    <Bell className="h-6 w-6 text-gray-600" />
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                      {notifications.filter((n) => !n.read).length}
                    </span>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        !notification.read ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"
                      }`}
                      onClick={() => markNotificationRead(notification.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-2 h-2 rounded-full mt-2 ${
                              !notification.read ? "bg-blue-600" : "bg-gray-400"
                            }`}
                          />
                          <div>
                            <p className="font-medium text-sm">{notification.message}</p>
                            <p className="text-xs text-gray-500">{notification.time}</p>
                          </div>
                        </div>
                        {notification.type === "match" && (
                          <Badge variant="secondary" className="bg-green-100 text-green-800">
                            New Match
                          </Badge>
                        )}
                        {notification.type === "application" && (
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                            Application
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Email Notification Demo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Email Notifications
                </CardTitle>
                <CardDescription>You'll receive email confirmations for all important actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-gray-50 border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Mail className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-sm">Sample Email Notification</span>
                    </div>
                    <div className="text-sm space-y-1">
                      <p>
                        <strong>To:</strong> {studentProfile.email}
                      </p>
                      <p>
                        <strong>Subject:</strong> Application Confirmation - Frontend Developer Intern
                      </p>
                      <div className="mt-2 p-2 bg-white border rounded text-xs">
                        <p>Hi {studentProfile.name},</p>
                        <p className="mt-1">
                          Your application for Frontend Developer Intern at TechStart Inc. has been successfully
                          submitted.
                        </p>
                        <p className="mt-1">We'll notify you of any updates regarding your application status.</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium text-green-800">
                        Email notifications are automatically sent for applications, messages, and status updates!
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {features.map((feature) => {
        const Icon = feature.icon
        const isExpanded = expandedFeature === feature.id

        return (
          <Card
            key={feature.id}
            className={`transition-all duration-300 ${isExpanded ? "ring-2 ring-blue-200" : "hover:shadow-lg"}`}
          >
            <CardHeader className="cursor-pointer" onClick={() => toggleFeature(feature.id)}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-lg ${feature.bgColor}`}>
                    <Icon className={`h-8 w-8 ${feature.color}`} />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                    <CardDescription className="text-base">{feature.description}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    {isExpanded ? "Hide Demo" : "Try Demo"}
                  </Button>
                  {isExpanded ? (
                    <ChevronUp className="h-5 w-5 text-gray-400" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-400" />
                  )}
                </div>
              </div>
            </CardHeader>

            {isExpanded && (
              <CardContent className="pt-0">
                <div className="border-t pt-6">{renderFeatureDemo(feature.id)}</div>
              </CardContent>
            )}
          </Card>
        )
      })}
    </div>
  )
}
