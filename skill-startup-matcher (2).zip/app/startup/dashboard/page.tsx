"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Bell,
  Search,
  Plus,
  MapPin,
  Clock,
  Users,
  TrendingUp,
  MessageSquare,
  Star,
  Briefcase,
  Eye,
  Zap,
} from "lucide-react"

// Mock data
const mockOpportunities = [
  {
    id: 1,
    title: "Frontend Developer Intern",
    type: "Internship",
    location: "Remote",
    duration: "3 months",
    compensation: "$1,500/month",
    skills: ["React", "JavaScript", "UI/UX Design"],
    applicants: 24,
    views: 156,
    status: "Active",
    posted: "2 days ago",
  },
  {
    id: 2,
    title: "Mobile App Developer",
    type: "Gig",
    location: "San Francisco, CA",
    duration: "1 month",
    compensation: "$3,000",
    skills: ["React Native", "Mobile Development"],
    applicants: 12,
    views: 89,
    status: "Active",
    posted: "1 week ago",
  },
  {
    id: 3,
    title: "AI/ML Hackathon",
    type: "Hackathon",
    location: "New York, NY",
    duration: "48 hours",
    compensation: "$5,000 prize",
    skills: ["Python", "Machine Learning"],
    applicants: 45,
    views: 234,
    status: "Closed",
    posted: "2 weeks ago",
  },
]

const mockCandidates = [
  {
    id: 1,
    name: "Sarah Johnson",
    university: "MIT",
    year: "4th Year",
    skills: ["React", "Node.js", "Python"],
    matchScore: 95,
    location: "Boston, MA",
    availability: "Full-time",
    appliedFor: "Frontend Developer Intern",
  },
  {
    id: 2,
    name: "Mike Chen",
    university: "Stanford",
    year: "3rd Year",
    skills: ["React Native", "JavaScript", "UI/UX"],
    matchScore: 88,
    location: "San Francisco, CA",
    availability: "Part-time",
    appliedFor: "Mobile App Developer",
  },
  {
    id: 3,
    name: "Emily Davis",
    university: "UC Berkeley",
    year: "Graduate",
    skills: ["Python", "Machine Learning", "Data Science"],
    matchScore: 92,
    location: "Berkeley, CA",
    availability: "Flexible",
    appliedFor: "AI/ML Hackathon",
  },
]

export default function StartupDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTab, setSelectedTab] = useState("opportunities")

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800"
      case "Closed":
        return "bg-red-100 text-red-800"
      case "Draft":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 80) return "text-blue-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <Zap className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">SkillMatch</span>
            </Link>

            <div className="flex items-center space-x-4">
              <Button asChild>
                <Link href="/startup/post-opportunity">
                  <Plus className="h-4 w-4 mr-2" />
                  Post Opportunity
                </Link>
              </Button>
              <div className="relative">
                <Bell className="h-6 w-6 text-gray-600 cursor-pointer" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  5
                </span>
              </div>
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback>TC</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardHeader className="text-center">
                <Avatar className="h-20 w-20 mx-auto mb-4">
                  <AvatarImage src="/placeholder.svg?height=80&width=80" />
                  <AvatarFallback className="text-2xl">TC</AvatarFallback>
                </Avatar>
                <CardTitle>TechCorp Inc.</CardTitle>
                <CardDescription>AI & Machine Learning</CardDescription>
                <div className="flex justify-center mt-2">
                  <Badge variant="secondary">Verified</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Profile Completion</span>
                      <span>92%</span>
                    </div>
                    <Progress value={92} />
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Focus Areas</h4>
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="outline" className="text-xs">
                        AI/ML
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Web Dev
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Mobile
                      </Badge>
                    </div>
                  </div>

                  <Button className="w-full" asChild>
                    <Link href="/startup/profile">Edit Profile</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Briefcase className="h-4 w-4 text-blue-600" />
                    <span className="text-sm">Active Posts</span>
                  </div>
                  <span className="font-semibold">3</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Total Applicants</span>
                  </div>
                  <span className="font-semibold">81</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Eye className="h-4 w-4 text-purple-600" />
                    <span className="text-sm">Profile Views</span>
                  </div>
                  <span className="font-semibold">479</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="h-4 w-4 text-orange-600" />
                    <span className="text-sm">Messages</span>
                  </div>
                  <span className="font-semibold">12</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, TechCorp!</h1>
              <p className="text-gray-600">Manage your opportunities and connect with talented students</p>
            </div>

            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Applications</p>
                      <p className="text-3xl font-bold text-blue-600">81</p>
                    </div>
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                  <p className="text-sm text-green-600 mt-2">↑ 12% from last week</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Avg Match Score</p>
                      <p className="text-3xl font-bold text-green-600">89%</p>
                    </div>
                    <Star className="h-8 w-8 text-green-600" />
                  </div>
                  <p className="text-sm text-green-600 mt-2">↑ 5% improvement</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Response Rate</p>
                      <p className="text-3xl font-bold text-purple-600">76%</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-purple-600" />
                  </div>
                  <p className="text-sm text-green-600 mt-2">↑ 8% from last month</p>
                </CardContent>
              </Card>
            </div>

            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="opportunities">My Opportunities</TabsTrigger>
                <TabsTrigger value="candidates">Candidates</TabsTrigger>
                <TabsTrigger value="messages">Messages</TabsTrigger>
              </TabsList>

              <TabsContent value="opportunities" className="space-y-6">
                {/* Opportunities List */}
                <div className="space-y-4">
                  {mockOpportunities.map((opportunity) => (
                    <Card key={opportunity.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-xl">{opportunity.title}</CardTitle>
                            <div className="flex items-center space-x-4 mt-2">
                              <Badge className={getStatusColor(opportunity.status)}>{opportunity.status}</Badge>
                              <Badge variant="outline">{opportunity.type}</Badge>
                            </div>
                          </div>
                          <div className="text-right">
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div className="flex items-center space-x-2">
                              <MapPin className="h-4 w-4 text-gray-400" />
                              <span>{opportunity.location}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Clock className="h-4 w-4 text-gray-400" />
                              <span>{opportunity.duration}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Users className="h-4 w-4 text-gray-400" />
                              <span>{opportunity.applicants} applicants</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Eye className="h-4 w-4 text-gray-400" />
                              <span>{opportunity.views} views</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {opportunity.skills.map((skill) => (
                              <Badge key={skill} variant="outline">
                                {skill}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex justify-between items-center pt-4">
                            <span className="text-sm text-gray-500">Posted {opportunity.posted}</span>
                            <div className="space-x-2">
                              <Button variant="outline">View Applications</Button>
                              <Button>Manage</Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="candidates" className="space-y-6">
                {/* Search */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex gap-4">
                      <div className="flex-1 relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder="Search candidates..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                      <Button variant="outline">
                        <Plus className="h-4 w-4 mr-2" />
                        Invite Candidates
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Candidates List */}
                <div className="space-y-4">
                  {mockCandidates.map((candidate) => (
                    <Card key={candidate.id}>
                      <CardContent className="pt-6">
                        <div className="flex justify-between items-start">
                          <div className="flex items-start space-x-4">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={`/placeholder.svg?height=48&width=48`} />
                              <AvatarFallback>
                                {candidate.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div className="space-y-2">
                              <div>
                                <h3 className="text-lg font-semibold">{candidate.name}</h3>
                                <p className="text-gray-600">
                                  {candidate.university} • {candidate.year}
                                </p>
                                <p className="text-sm text-gray-500">
                                  {candidate.location} • {candidate.availability}
                                </p>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {candidate.skills.map((skill) => (
                                  <Badge key={skill} variant="outline" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>
                              <p className="text-sm text-blue-600">Applied for: {candidate.appliedFor}</p>
                            </div>
                          </div>
                          <div className="text-right space-y-2">
                            <div className={`text-2xl font-bold ${getMatchScoreColor(candidate.matchScore)}`}>
                              {candidate.matchScore}%
                            </div>
                            <div className="text-sm text-gray-500">Match</div>
                            <div className="space-x-2">
                              <Button variant="outline" size="sm">
                                View Profile
                              </Button>
                              <Button size="sm">Contact</Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="messages" className="space-y-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-8">
                      <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">No new messages</h3>
                      <p className="text-gray-600">Your conversations with candidates will appear here.</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
