"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Bell, Search, Filter, MapPin, Clock, DollarSign, MessageSquare, Star, Briefcase, Zap } from "lucide-react"

// Mock data
const mockOpportunities = [
  {
    id: 1,
    title: "Frontend Developer Intern",
    company: "TechStart Inc.",
    type: "Internship",
    location: "Remote",
    duration: "3 months",
    compensation: "$1,500/month",
    skills: ["React", "JavaScript", "UI/UX Design"],
    matchScore: 95,
    description: "Join our team to build the next generation of web applications...",
    posted: "2 days ago",
  },
  {
    id: 2,
    title: "AI/ML Hackathon",
    company: "DataCorp",
    type: "Hackathon",
    location: "San Francisco, CA",
    duration: "48 hours",
    compensation: "$5,000 prize pool",
    skills: ["Python", "Machine Learning", "Data Science"],
    matchScore: 88,
    description: "Build innovative AI solutions for real-world problems...",
    posted: "1 week ago",
  },
  {
    id: 3,
    title: "Mobile App Development Gig",
    company: "StartupXYZ",
    type: "Gig",
    location: "New York, NY",
    duration: "2 weeks",
    compensation: "$2,000",
    skills: ["React Native", "Mobile Development", "JavaScript"],
    matchScore: 82,
    description: "Help us build a mobile app for our growing user base...",
    posted: "3 days ago",
  },
]

const mockApplications = [
  {
    id: 1,
    title: "Backend Developer Intern",
    company: "CloudTech",
    status: "Under Review",
    appliedDate: "2024-01-15",
    matchScore: 91,
  },
  {
    id: 2,
    title: "UX Design Hackathon",
    company: "DesignHub",
    status: "Accepted",
    appliedDate: "2024-01-10",
    matchScore: 87,
  },
  {
    id: 3,
    title: "Full Stack Developer",
    company: "WebSolutions",
    status: "Rejected",
    appliedDate: "2024-01-08",
    matchScore: 79,
  },
]

export default function StudentDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTab, setSelectedTab] = useState("opportunities")

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Accepted":
        return "bg-green-100 text-green-800"
      case "Under Review":
        return "bg-yellow-100 text-yellow-800"
      case "Rejected":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 80) return "text-blue-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <Zap className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">SkillMatch</span>
            </Link>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="h-6 w-6 text-gray-600 cursor-pointer" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  3
                </span>
              </div>
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback>JS</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardHeader className="text-center">
                <Avatar className="h-20 w-20 mx-auto mb-4">
                  <AvatarImage src="/placeholder.svg?height=80&width=80" />
                  <AvatarFallback className="text-2xl">JS</AvatarFallback>
                </Avatar>
                <CardTitle>John Smith</CardTitle>
                <CardDescription>Computer Science Student</CardDescription>
                <div className="flex justify-center mt-2">
                  <Badge variant="secondary">3rd Year</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Profile Completion</span>
                      <span>85%</span>
                    </div>
                    <Progress value={85} />
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Top Skills</h4>
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="outline" className="text-xs">
                        React
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Python
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Node.js
                      </Badge>
                    </div>
                  </div>

                  <Button className="w-full" asChild>
                    <Link href="/student/profile">Edit Profile</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Briefcase className="h-4 w-4 text-blue-600" />
                    <span className="text-sm">Applications</span>
                  </div>
                  <span className="font-semibold">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Star className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Avg Match Score</span>
                  </div>
                  <span className="font-semibold">87%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Messages</span>
                  </div>
                  <span className="font-semibold">5</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, John!</h1>
              <p className="text-gray-600">Here are your latest opportunities and updates</p>
            </div>

            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
                <TabsTrigger value="applications">My Applications</TabsTrigger>
                <TabsTrigger value="messages">Messages</TabsTrigger>
              </TabsList>

              <TabsContent value="opportunities" className="space-y-6">
                {/* Search and Filter */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex gap-4">
                      <div className="flex-1 relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder="Search opportunities..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                      <Button variant="outline">
                        <Filter className="h-4 w-4 mr-2" />
                        Filters
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Opportunities List */}
                <div className="space-y-4">
                  {mockOpportunities.map((opportunity) => (
                    <Card key={opportunity.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-xl">{opportunity.title}</CardTitle>
                            <CardDescription className="text-lg font-medium text-blue-600">
                              {opportunity.company}
                            </CardDescription>
                          </div>
                          <div className="text-right">
                            <div className={`text-2xl font-bold ${getMatchScoreColor(opportunity.matchScore)}`}>
                              {opportunity.matchScore}%
                            </div>
                            <div className="text-sm text-gray-500">Match</div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <p className="text-gray-600">{opportunity.description}</p>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div className="flex items-center space-x-2">
                              <Badge variant="secondary">{opportunity.type}</Badge>
                            </div>
                            <div className="flex items-center space-x-2">
                              <MapPin className="h-4 w-4 text-gray-400" />
                              <span>{opportunity.location}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Clock className="h-4 w-4 text-gray-400" />
                              <span>{opportunity.duration}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <DollarSign className="h-4 w-4 text-gray-400" />
                              <span>{opportunity.compensation}</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {opportunity.skills.map((skill) => (
                              <Badge key={skill} variant="outline">
                                {skill}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex justify-between items-center pt-4">
                            <span className="text-sm text-gray-500">Posted {opportunity.posted}</span>
                            <div className="space-x-2">
                              <Button variant="outline">Learn More</Button>
                              <Button>Apply Now</Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="applications" className="space-y-6">
                <div className="space-y-4">
                  {mockApplications.map((application) => (
                    <Card key={application.id}>
                      <CardContent className="pt-6">
                        <div className="flex justify-between items-start">
                          <div className="space-y-2">
                            <h3 className="text-lg font-semibold">{application.title}</h3>
                            <p className="text-blue-600 font-medium">{application.company}</p>
                            <p className="text-sm text-gray-500">Applied on {application.appliedDate}</p>
                          </div>
                          <div className="text-right space-y-2">
                            <Badge className={getStatusColor(application.status)}>{application.status}</Badge>
                            <div className={`text-lg font-bold ${getMatchScoreColor(application.matchScore)}`}>
                              {application.matchScore}% Match
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="messages" className="space-y-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-8">
                      <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">No messages yet</h3>
                      <p className="text-gray-600">When startups reach out to you, their messages will appear here.</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
