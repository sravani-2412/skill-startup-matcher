"use client"

import type React from "react"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Zap, User, Building, X } from "lucide-react"

const skillOptions = [
  "JavaScript",
  "Python",
  "React",
  "Node.js",
  "UI/UX Design",
  "Data Science",
  "Machine Learning",
  "Mobile Development",
  "DevOps",
  "Blockchain",
  "AI",
  "Cybersecurity",
  "Cloud Computing",
  "Digital Marketing",
  "Product Management",
]

const interestOptions = [
  "FinTech",
  "EdTech",
  "HealthTech",
  "E-commerce",
  "SaaS",
  "Gaming",
  "Social Media",
  "IoT",
  "AR/VR",
  "Sustainability",
  "Food Tech",
  "Travel Tech",
]

export default function RegisterPage() {
  const searchParams = useSearchParams()
  const initialType = searchParams.get("type") || "student"

  const [userType, setUserType] = useState<"student" | "startup">(initialType as "student" | "startup")
  const [selectedSkills, setSelectedSkills] = useState<string[]>([])
  const [selectedInterests, setSelectedInterests] = useState<string[]>([])
  const [customSkill, setCustomSkill] = useState("")
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    university: "",
    year: "",
    company: "",
    description: "",
    website: "",
    location: "",
    availability: "",
  })

  const addSkill = (skill: string) => {
    if (!selectedSkills.includes(skill)) {
      setSelectedSkills([...selectedSkills, skill])
    }
  }

  const removeSkill = (skill: string) => {
    setSelectedSkills(selectedSkills.filter((s) => s !== skill))
  }

  const addCustomSkill = () => {
    if (customSkill && !selectedSkills.includes(customSkill)) {
      setSelectedSkills([...selectedSkills, customSkill])
      setCustomSkill("")
    }
  }

  const toggleInterest = (interest: string) => {
    if (selectedInterests.includes(interest)) {
      setSelectedInterests(selectedInterests.filter((i) => i !== interest))
    } else {
      setSelectedInterests([...selectedInterests, interest])
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle registration logic here
    console.log("Registration data:", { userType, formData, selectedSkills, selectedInterests })
    // Redirect to dashboard
    window.location.href = userType === "student" ? "/student/dashboard" : "/startup/dashboard"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-6">
            <Zap className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">SkillMatch</span>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Your Account</h1>
          <p className="text-gray-600">Join the community and start matching today</p>
        </div>

        <div className="max-w-2xl mx-auto">
          {/* User Type Selection */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>I am a...</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant={userType === "student" ? "default" : "outline"}
                  onClick={() => setUserType("student")}
                  className="h-20 flex flex-col items-center space-y-2"
                >
                  <User className="h-6 w-6" />
                  <span>Student</span>
                </Button>
                <Button
                  variant={userType === "startup" ? "default" : "outline"}
                  onClick={() => setUserType("startup")}
                  className="h-20 flex flex-col items-center space-y-2"
                >
                  <Building className="h-6 w-6" />
                  <span>Startup</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          <form onSubmit={handleSubmit}>
            {/* Basic Information */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">{userType === "student" ? "Full Name" : "Contact Name"}</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    required
                  />
                </div>

                {userType === "student" ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="university">University</Label>
                      <Input
                        id="university"
                        value={formData.university}
                        onChange={(e) => setFormData({ ...formData, university: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="year">Year of Study</Label>
                      <Select onValueChange={(value) => setFormData({ ...formData, year: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select year" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1st Year</SelectItem>
                          <SelectItem value="2">2nd Year</SelectItem>
                          <SelectItem value="3">3rd Year</SelectItem>
                          <SelectItem value="4">4th Year</SelectItem>
                          <SelectItem value="graduate">Graduate</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="company">Company Name</Label>
                      <Input
                        id="company"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="website">Website (Optional)</Label>
                      <Input
                        id="website"
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        placeholder="https://yourcompany.com"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="City, Country or Remote"
                    required
                  />
                </div>
              </CardContent>
            </Card>

            {/* Skills Section */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>{userType === "student" ? "Your Skills" : "Skills You're Looking For"}</CardTitle>
                <CardDescription>
                  {userType === "student"
                    ? "Select your technical and soft skills"
                    : "What skills do you need for your opportunities?"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {skillOptions.map((skill) => (
                    <Button
                      key={skill}
                      type="button"
                      variant={selectedSkills.includes(skill) ? "default" : "outline"}
                      size="sm"
                      onClick={() => (selectedSkills.includes(skill) ? removeSkill(skill) : addSkill(skill))}
                    >
                      {skill}
                    </Button>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Input
                    placeholder="Add custom skill"
                    value={customSkill}
                    onChange={(e) => setCustomSkill(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addCustomSkill())}
                  />
                  <Button type="button" onClick={addCustomSkill}>
                    Add
                  </Button>
                </div>

                {selectedSkills.length > 0 && (
                  <div className="space-y-2">
                    <Label>Selected Skills:</Label>
                    <div className="flex flex-wrap gap-2">
                      {selectedSkills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                          {skill}
                          <X className="h-3 w-3 cursor-pointer" onClick={() => removeSkill(skill)} />
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Interests Section */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Industry Interests</CardTitle>
                <CardDescription>What industries are you interested in?</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {interestOptions.map((interest) => (
                    <div key={interest} className="flex items-center space-x-2">
                      <Checkbox
                        id={interest}
                        checked={selectedInterests.includes(interest)}
                        onCheckedChange={() => toggleInterest(interest)}
                      />
                      <Label htmlFor={interest} className="text-sm">
                        {interest}
                      </Label>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Additional Information */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Additional Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {userType === "student" && (
                  <div>
                    <Label htmlFor="availability">Availability</Label>
                    <Select onValueChange={(value) => setFormData({ ...formData, availability: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select availability" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full-time">Full-time</SelectItem>
                        <SelectItem value="part-time">Part-time</SelectItem>
                        <SelectItem value="weekends">Weekends only</SelectItem>
                        <SelectItem value="flexible">Flexible</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div>
                  <Label htmlFor="description">{userType === "student" ? "About You" : "About Your Company"}</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder={
                      userType === "student"
                        ? "Tell us about yourself, your goals, and what you're looking for..."
                        : "Describe your company, mission, and what makes it unique..."
                    }
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-4">
              <Button type="submit" className="flex-1">
                Create Account
              </Button>
              <Button type="button" variant="outline" asChild>
                <Link href="/login">Already have an account?</Link>
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
